export const ACCESS_TOKEN = "@access-token";
export const USER_INFO = "@user-info";
export const USER_AVATAR = "@user-avatar";
