import React from "react";
import { View, Text } from "react-native";

export default function Offers() {
  return (
    <View>
      <Text>Pagina de Ofertas 2</Text>
    </View>
  );
}
