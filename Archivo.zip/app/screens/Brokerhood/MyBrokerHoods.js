import React from "react";
import { View, Text } from "react-native";

export default function MyBrokerHoods(props) {
  const { navigation } = props;
  return (
    <View>
      <Text>ACA EMPIEZA LA FIESTA</Text>
    </View>
  );
}
