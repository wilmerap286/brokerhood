import React from "react";
import { View, Text } from "react-native";

export default function Orders() {
  return (
    <View>
      <Text>Pagina de Pedidos</Text>
    </View>
  );
}
