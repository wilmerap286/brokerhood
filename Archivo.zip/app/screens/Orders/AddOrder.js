import React from "react";
import { View, Text } from "react-native";

export default function AddOader() {
  return (
    <View>
      <Text>Agregar Nuevo Pedido</Text>
    </View>
  );
}
