export const FacebookApi = {
  application_id: "484170798920768",
  permissions: ["email", "public_profile"]
};
